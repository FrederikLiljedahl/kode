function kommentar_slet(id, idet) {
    if (confirm(`Er du helt sikker på du vil slette denne kommentar`)) {
        var url = window.location.pathname;
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        let init = {
            method: 'delete',
            headers: headers,
            body: JSON.stringify({
                id: id
            }),
            cache: 'no-cache',
            cors: 'cors'
        };

        let request = new Request(url, init);
        fetch(request)
            .then(response => {
                if (response.status == 200) {
                    console.log(`id nr:${id} slettet`);
                    alert(`kommentar slettet `);
                    location.href = `http://www.frederikliljedahl.dk:1280/admin/artikler/kommentare/${idet}`;
                } else {
                    console.log(`err ${response.status}`);
                }
            }).catch(err => {
                console.log(err);
            });

    } else {
        console.log('annulleret')
    }
}
