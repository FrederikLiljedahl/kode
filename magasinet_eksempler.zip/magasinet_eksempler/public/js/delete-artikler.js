function artikler_slet(id) {
    if (confirm(`Er du helt sikker på du vil slette denne artikel?`)) {
        var url = window.location.pathname;
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        let init = {
            method: 'delete',
            headers: headers,
            body: JSON.stringify({
                id: id
            }),
            cache: 'no-cache',
            cors: 'cors'
        };

        let request = new Request(url, init);
        fetch(request)
            .then(response => {
                if (response.status == 200) {
                    console.log(`id nr:${id} slettet`);
                    alert(`artikler slettet `);
                    location.href = `http://www.frederikliljedahl.dk:1280/admin/artikler`;
                } else {
                    console.log(`err ${response.status}`);
                }
            }).catch(err => {
                console.log(err);
            });

    } else {
        console.log('annulleret')
    }
}
