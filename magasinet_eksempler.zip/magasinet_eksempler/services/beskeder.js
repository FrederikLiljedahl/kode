module.exports = {
    beskeder: `SELECT id,navn,besked,emne, DATE_FORMAT(dato, "%d-%m-%y") AS 'date', TIMEDIFF(now(),dato) as tid, DATEDIFF(now(),dato) as dage from kontakt ORDER BY dato DESC limit 3`,

    checktime: (kontakt_tid) => {
        var kontakt_array = []

        kontakt_tid.forEach(function (kontakt) {
            var dato = kontakt.date
            var tid = kontakt.tid
            var dage = kontakt.dage
            var minutterposition = tid.indexOf(":")
            var positionplus = minutterposition + 1;
            var minutter = tid.slice(positionplus, tid.indexOf(":", positionplus));
            var timer = tid.slice(0, tid.indexOf(":"))
            var tiden = timer / 24
            if (tiden >= 1) {
                if (dage == 1) {
                    kontakt_array.push(dage + " Dag siden")
                } else if (dage <= 2) {
                    kontakt_array.push("I forgårs")
                }
                else if (dage <= 7) {
                    kontakt_array.push("Denne uge")
                }
                else if (dage <= 30) {
                    kontakt_array.push("Over 2 uger siden")
                } else if (dage <= 60) {
                    kontakt_array.push("Over et måned siden")
                } else {
                    kontakt_array.push(dato)
                }
            } else if (tiden > 0) {
                kontakt_array.push(timer + " Timer siden")
            } else if (minutter == 0) {
                kontakt_array.push("Nu")
            } else {
                kontakt_array.push(minutter + " Minutter siden")
            }
        })
        return kontakt_array;
    }
}