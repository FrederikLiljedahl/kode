const fs = require('fs');
module.exports = {
    deleteArtikler: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `delete from artikler where fk_medarbejder_id = ?`;
            db.query(sql, id, function (err, result) {
                if (err) reject(err)
                resolve(result)
            });
        })
    },
    deleteBruger: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `delete from brugere where fk_medarbejder = ?`;
            db.query(sql, id, function (err, result) {
                if (err) reject(err)
                resolve(result)
            });
        })
    },
    deleteMedarbejder: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `delete from medarbejder where medarbejder_id = ?`;
            db.query(sql, id, function (err, result) {
                if (err) reject(err)
                resolve(result)
            });
        })
    }, deletePathMedarbejder: (id) => {
        return new Promise((resolve, reject) => {
            db.query(`select billede from medarbejder where medarbejder_id = ?`, id, function (err, img) {
                if (err) {
                    console.log(error)
                    reject(error)
                } else {
                    fs.unlink(`${__dirname}/../public/img/${img[0].billede}`)
                    resolve(img)
                }


            })
        })
    }, kontakt_info: (beskeder) => {
        return new Promise((resolve, reject) => {
            db.query(beskeder, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    }, sponsor: () => {
        return new Promise((resolve, reject) => {
            db.query(`select sponsor.billede, sponsor.id, kategori.kategori_navn from sponsor 
            inner join kategori on sponsor.fk_kategori_id = kategori.id`, function (err, result) {
                    if (err) {
                        reject(err)
                    } else {
                        resolve(result)
                    }
                })
        })
    }, sponsor_opret: (file, kategori) => {
        return new Promise((resolve, reject) => {
            db.query(`insert into sponsor set billede = ?, fk_kategori_id = ?`, [file, kategori], function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    }, deletePathSponsor: (id) => {
        return new Promise((resolve, reject) => {
            db.query(`select billede from sponsor where id = ?`, id, function (err, img) {
                if (err) {
                    console.log(err)
                    reject(err)
                } else {
                    fs.unlink(`${__dirname}/../public/img/${img[0].billede}`)
                    resolve(img)
                }


            })
        })
    }
    , deleteSponsor: (id) => {
        return new Promise((resolve, reject) => {
            db.query(`delete from sponsor where id = ?`, id, function (err, result) {
                if (err) {
                    console.log(err)
                    reject(err)
                } else {
                    resolve(result)
                }


            })
        })
    }, HentSponsor: (id) => {
        return new Promise((resolve, reject) => {
            db.query(`select sponsor.fk_kategori_id, kategori.kategori_navn from sponsor 
            inner join kategori on sponsor.fk_kategori_id = kategori.id where sponsor.id = ?`, id, function (err, result) {
                    if (err) {
                        console.log(err)
                        reject(err)
                    } else {
                        resolve(result)
                    }
                })
        })
    }, sponsor_kategori_ret: (kategori, id) => {
        return new Promise((resolve, reject) => {
            db.query(`update sponsor set  fk_kategori_id = ? where id = ?`, [kategori, id], function (err, result) {
                if (err) {
                    console.log(err)
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    }, sponsor_alt_ret: (kategori, file, id) => {
        return new Promise((resolve, reject) => {
            db.query(`update sponsor set fk_kategori_id = ?, billede = ? where id = ?`, [kategori, file, id], function (err, result) {
                if (err) {
                    console.log(err)
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    sponsorText: () => {
        return new Promise((resolve, reject) => {
            db.query(`select * from sponsortext`, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    }, sponsorData: () => {
        return new Promise((resolve, reject) => {
            db.query(`select * from sponsordata`, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    kontaktText: () => {
        return new Promise((resolve, reject) => {
            db.query(`select * from oplysninger`, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    }, updateKontakt: (adresse, postnummer, byen, land, telefon, fax, mail) => {
        return new Promise((resolve, reject) => {
            db.query(`update oplysninger set adresse = ?, postnummer = ?, byen = ?, land = ?, telefon = ?, fax = ?, mail = ?`, [adresse, postnummer, byen, land, telefon, fax, mail], function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    }, updateSponsortext: (tekst) => {
        return new Promise((resolve, reject) => {
            db.query(`update sponsortext set tekst = ?`, [tekst], function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    }, updateSponsordata: (visninger, pris_per_visning, id) => {
        return new Promise((resolve, reject) => {
            db.query(`update sponsordata set visninger = ?, pris_per_visning = ? where sponsor_data_id = ?`, [visninger, pris_per_visning, id], function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    }, EnSponsorData: (id) => {
        return new Promise((resolve, reject) => {
            db.query(`select * from sponsordata where sponsor_data_id = ?`, id, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    artikler: (add) => {
        return new Promise((resolve, reject) => {
            let sql = `SELECT artikler.overskrift,artikler.fk_kategori_id, artikler.id, kategori.kategori_navn, medarbejder.navn
            FROM artikler
            inner join kategori on artikler.fk_kategori_id = kategori.id
            inner join medarbejder on artikler.fk_medarbejder_id = medarbejder.medarbejder_id`
            sql += add
            db.query(sql, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    enMedarbejder: (id) => {
        return new Promise((resolve, reject) => {
            db.query(`SELECT medarbejder.medarbejder_id, medarbejder.navn, kategori.kategori_navn, roller.rolle, medarbejder.fk_kategori_id
            FROM medarbejder
            inner join kategori on medarbejder.fk_kategori_id = kategori.id
            inner join roller on medarbejder.rolle = roller.id
			where medarbejder.medarbejder_id = ?`, id, function (err, result) {
                    if (err) {
                        reject(err)
                    } else {
                        resolve(result)
                    }
                })
        })
    },
    insertArtikel: (overskrift, tekst, dato, medarbejder_id, kategori_id) => {
        return new Promise((resolve, reject) => {
            db.query(`insert into artikler set overskrift = ?, tekst = ?, dato = ?, fk_medarbejder_id = ?,
            fk_kategori_id = ?, visninger = 0`, [overskrift, tekst, dato, medarbejder_id, kategori_id], function (err, result) {
                    if (err) {
                        reject(err)
                    } else {
                        resolve(result)
                    }
                })
        })
    },
    hentEnArtikel: (id) => {
        return new Promise((resolve, reject) => {
            let sql = `SELECT artikler.overskrift,artikler.fk_kategori_id, artikler.id, kategori.kategori_navn,
            medarbejder.navn, DATE_FORMAT(artikler.dato, "%Y-%m-%dT%H:%i") AS 'date', artikler.tekst
            FROM artikler
            inner join kategori on artikler.fk_kategori_id = kategori.id
            inner join medarbejder on artikler.fk_medarbejder_id = medarbejder.medarbejder_id
            where artikler.id = ?`
            db.query(sql, id, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    updateEnArtikel: (overskrift, tekst, dato, kategori_id, id) => {
        return new Promise((resolve, reject) => {
            let sql = `update artikler set overskrift = ?, tekst = ?, dato = ?, fk_kategori_id = ? where id = ?`
            db.query(sql, [overskrift, tekst, dato, kategori_id, id], function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    deleteArtikel: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `delete from artikler where id= ?`;
            db.query(sql, id, function (err, result) {
                if (err) reject(err)
                resolve(result)
            });
        })
    }, deleteKommentare: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `delete from kommentare where artikel = ?`;
            db.query(sql, id, function (err, result) {
                if (err) reject(err)
                resolve(result)
            });
        })
    },
    hentEnBestemArtikel: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `SELECT artikler.id
            from artikler
            where artikler.fk_medarbejder_id = ?`
            db.query(sql, id, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    insertIntoLog: function (txt) {
        return new Promise((resolve, reject) => {
            fs.appendFile('log.txt', txt, function (err) {
                if (err) {
                    reject(err)
                } else {
                    resolve()
                }
            });
        })
    },
    hentEnOverskrift: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `SELECT artikler.overskrift
            from artikler
            where artikler.id = ?`
            db.query(sql, id, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    kommentare: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `select * from kommentare where artikel = ?`
            db.query(sql, id, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    kommentar: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `select * from kommentare where id = ?`
            db.query(sql, id, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    updateKommentar: function (kommentar, id) {
        return new Promise((resolve, reject) => {
            let sql = `update kommentare set kommentar = ? where id = ?`
            db.query(sql, [kommentar, id], function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },
    sletKommentar: function (id) {
        return new Promise((resolve, reject) => {
            let sql = `delete from kommentare where id = ?`
            db.query(sql, id, function (err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            })
        })
    },



}