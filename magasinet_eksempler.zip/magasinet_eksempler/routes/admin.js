const passwordHash = require('password-hash');
const fileupload = require('../services/upload.js')
const querys = require('../services/backend-querys.js')
const beskedersql = require('../services/beskeder.js')
const fs = require('fs');
const formidable = require('formidable');
const sharp = require('sharp');

module.exports = function (app) {

    // Render admin/artikler

    app.get('/admin/artikler/', async function (req, res) {
        var user = req.session.user;
        let beskeder = beskedersql.beskeder
        let userId = req.session.userId
        let userRole = req.session.userRole
        let formShow = false;

        if (userId == null) {
            res.redirect("/logind");
            return;
        }
        let medarbejder_id = req.session.user.fk_medarbejder
        try {
            let user_kategori_id = req.session.user.fk_kategori_id
            if (user_kategori_id == '4') {
                let artikler = await querys.artikler('')
                let enmedarbejder = await querys.enMedarbejder(medarbejder_id)
                let kontakt_info = await querys.kontakt_info(beskeder)
                let checktimefunc = await beskedersql.checktime(kontakt_info)
                res.render('admin/pages/artikler', {
                    kontakt_info: kontakt_info,
                    kontakt_array: checktimefunc,
                    user: user,
                    userRole: userRole,
                    artikler: artikler,
                    enmedarbejder: enmedarbejder,
                    formShow: formShow
                })
            } else {
                let wherestatement = ` where artikler.fk_kategori_id = ${user_kategori_id}`
                let artikler = await querys.artikler(wherestatement)
                let enmedarbejder = await querys.enMedarbejder(medarbejder_id)
                let kontakt_info = await querys.kontakt_info(beskeder)
                let checktimefunc = await beskedersql.checktime(kontakt_info)
                res.render('admin/pages/artikler', {
                    kontakt_info: kontakt_info,
                    kontakt_array: checktimefunc,
                    user: user,
                    userRole: userRole,
                    artikler: artikler,
                    enmedarbejder: enmedarbejder,
                    formShow: formShow
                })
            }
        }
        catch (err) {
            console.log(err)
        }
    })


    app.post('/admin/artikler/', async function (req, res) {
        var user = req.session.user;
        let beskeder = beskedersql.beskeder
        let userId = req.session.userId
        let userRole = req.session.userRole
        let overskrift = req.body.overskrift
        let tekst = req.body.tekst
        let dato = req.body.dato
        let message = ''
        let messageType = ''
        let formShow = false;
        let medarbejder_id = req.session.user.fk_medarbejder
        if (req.session.user.fk_kategori_id == '4') {
            let kategori_id = req.body.kategori
            try {
                let time = new Date().toLocaleTimeString('da', {
                    hour: "numeric",
                    minute: "numeric",
                    day: 'numeric',
                    month: 'numeric',
                    year: 'numeric'
                });

                let txt = `\n- Artikel Oprettet af ${req.session.user.navn} - d.${time} \n #############################`
                await querys.insertIntoLog(txt)
                await querys.insertArtikel(overskrift, tekst, dato, medarbejder_id, kategori_id)
                let artikler = await querys.artikler('')
                let enmedarbejder = await querys.enMedarbejder(medarbejder_id)
                let kontakt_info = await querys.kontakt_info(beskeder)
                let checktimefunc = await beskedersql.checktime(kontakt_info)
                message = 'Artikel Oprettet'
                res.render('admin/pages/artikler', {
                    kontakt_info: kontakt_info,
                    kontakt_array: checktimefunc,
                    user: user,
                    userRole: userRole,
                    artikler: artikler,
                    enmedarbejder: enmedarbejder,
                    message: message,
                    messageType: 'alert-success',
                    formShow: formShow
                })
            }
            catch (err) {
                console.log(err)
            }
        } else {
            let kategori_id = req.session.user.fk_kategori_id
            try {
                let time = new Date().toLocaleTimeString('da', {
                    hour: "numeric",
                    minute: "numeric",
                    day: 'numeric',
                    month: 'numeric',
                    year: 'numeric'
                });

                let txt = `\n- Artikel Oprettet af ${req.session.user.navn} - d.${time} \n #############################`
                await querys.insertIntoLog(txt)
                await querys.insertArtikel(overskrift, tekst, dato, medarbejder_id, kategori_id)
                let wherestatement = ` where artikler.fk_kategori_id = ${kategori_id}`
                let artikler = await querys.artikler(wherestatement)
                let enmedarbejder = await querys.enMedarbejder(medarbejder_id)
                let kontakt_info = await querys.kontakt_info(beskeder)
                let checktimefunc = await beskedersql.checktime(kontakt_info)
                message = 'Artikel Oprettet'
                res.render('admin/pages/artikler', {
                    kontakt_info: kontakt_info,
                    kontakt_array: checktimefunc,
                    user: user,
                    userRole: userRole,
                    artikler: artikler,
                    enmedarbejder: enmedarbejder,
                    message: message,
                    messageType: 'alert-success',
                    formShow: formShow
                })
            }
            catch (err) {
                console.log(err)
            }
        }
    })

    app.get('/admin/artikler/:id', async function (req, res) {
        var user = req.session.user;
        let beskeder = beskedersql.beskeder
        let userId = req.session.userId
        let userRole = req.session.userRole
        let id = req.params.id
        let formShow = false;
        formShow = true
        if (userId == null) {
            res.redirect("/logind");
            return;
        }
        let medarbejder_id = req.session.user.fk_medarbejder
        try {
            let user_kategori_id = req.session.user.fk_kategori_id
            if (user_kategori_id == '4') {
                let artikler = await querys.artikler('')
                let hentEnArtikel = await querys.hentEnArtikel(id)
                let enmedarbejder = await querys.enMedarbejder(medarbejder_id)
                let kontakt_info = await querys.kontakt_info(beskeder)
                let checktimefunc = await beskedersql.checktime(kontakt_info)
                res.render('admin/pages/artikler', {
                    kontakt_info: kontakt_info,
                    kontakt_array: checktimefunc,
                    user: user,
                    userRole: userRole,
                    artikler: artikler,
                    enmedarbejder: enmedarbejder,
                    formShow: formShow,
                    hentEnArtikel: hentEnArtikel
                })
            } else {
                let wherestatement = ` where artikler.fk_kategori_id = ${user_kategori_id}`
                let artikler = await querys.artikler(wherestatement)
                let hentEnArtikel = await querys.hentEnArtikel(id)
                let enmedarbejder = await querys.enMedarbejder(medarbejder_id)
                let kontakt_info = await querys.kontakt_info(beskeder)
                let checktimefunc = await beskedersql.checktime(kontakt_info)
                res.render('admin/pages/artikler', {
                    kontakt_info: kontakt_info,
                    kontakt_array: checktimefunc,
                    user: user,
                    userRole: userRole,
                    artikler: artikler,
                    enmedarbejder: enmedarbejder,
                    formShow: formShow,
                    hentEnArtikel: hentEnArtikel
                })
            }
        }
        catch (err) {
            console.log(err)
        }
    })

    app.post('/admin/artikler/:id', async function (req, res) {
        var user = req.session.user;
        let beskeder = beskedersql.beskeder
        let userId = req.session.userId
        let userRole = req.session.userRole
        let id = req.params.id
        let overskrift = req.body.overskrift
        let tekst = req.body.tekst
        let dato = req.body.dato
        let message = ''
        let messageType = ''

        let formShow = false;
        if (userId == null) {
            res.redirect("/logind");
            return;
        }
        let medarbejder_id = req.session.user.fk_medarbejder
        try {
            let user_kategori_id = req.session.user.fk_kategori_id
            if (user_kategori_id == '4') {
                let kategori_id = req.body.kategorien
                await querys.updateEnArtikel(overskrift, tekst, dato, kategori_id, id)
                let time = new Date().toLocaleTimeString('da', {
                    hour: "numeric",
                    minute: "numeric",
                    day: 'numeric',
                    month: 'numeric',
                    year: 'numeric'
                });

                let overskriften = await querys.hentEnOverskrift(id)
                let txt = `\n- "${overskriften[0].overskrift}" Artiklen redigeret af ${req.session.user.navn} - d.${time} \n #############################`
                await querys.insertIntoLog(txt)
                let artikler = await querys.artikler('')
                let hentEnArtikel = await querys.hentEnArtikel(id)
                let enmedarbejder = await querys.enMedarbejder(medarbejder_id)
                let kontakt_info = await querys.kontakt_info(beskeder)
                let checktimefunc = await beskedersql.checktime(kontakt_info)
                message = 'Artikel Redigeret'
                res.render('admin/pages/artikler', {
                    kontakt_info: kontakt_info,
                    kontakt_array: checktimefunc,
                    user: user,
                    userRole: userRole,
                    artikler: artikler,
                    enmedarbejder: enmedarbejder,
                    formShow: formShow,
                    hentEnArtikel: hentEnArtikel,
                    message: message,
                    messageType: 'alert-success',
                })
            } else {
                let kategori_id = req.session.user.fk_kategori_id
                await querys.updateEnArtikel(overskrift, tekst, dato, kategori_id, id)
                let time = new Date().toLocaleTimeString('da', {
                    hour: "numeric",
                    minute: "numeric",
                    day: 'numeric',
                    month: 'numeric',
                    year: 'numeric'
                });

                let overskriften = await querys.hentEnOverskrift(id)
                let txt = `\n- "${overskriften[0].overskrift}" Artiklen redigeret af ${req.session.user.navn} - d.${time} \n #############################`
                await querys.insertIntoLog(txt)
                let wherestatement = ` where artikler.fk_kategori_id = ${kategori_id}`
                let artikler = await querys.artikler(wherestatement)
                let hentEnArtikel = await querys.hentEnArtikel(id)
                let enmedarbejder = await querys.enMedarbejder(medarbejder_id)
                let kontakt_info = await querys.kontakt_info(beskeder)
                let checktimefunc = await beskedersql.checktime(kontakt_info)
                message = 'Artikel Redigeret'
                res.render('admin/pages/artikler', {
                    kontakt_info: kontakt_info,
                    kontakt_array: checktimefunc,
                    user: user,
                    userRole: userRole,
                    artikler: artikler,
                    enmedarbejder: enmedarbejder,
                    formShow: formShow,
                    hentEnArtikel: hentEnArtikel,
                    message: message,
                    messageType: 'alert-success',
                })
            }
        }
        catch (err) {
            console.log(err)
        }
    })

    app.delete(['/admin/artikler/:id', '/admin/artikler/'], async function (req, res) {
        let id = req.body.id;
        let time = new Date().toLocaleTimeString('da', {
            hour: "numeric",
            minute: "numeric",
            day: 'numeric',
            month: 'numeric',
            year: 'numeric'
        });

        let overskriften = await querys.hentEnOverskrift(id)
        let txt = `\n- "${overskriften[0].overskrift}" Artiklen slettet af ${req.session.user.navn} - d.${time} \n #############################`
        await querys.insertIntoLog(txt)
        await querys.deleteKommentare(id)
        await querys.deleteArtikel(id)
        await res.json(200)
    })
    
    app.get('/admin/artikler/kommentare/:id', async function (req, res) {
        var user = req.session.user;
        let beskeder = beskedersql.beskeder
        let userId = req.session.userId
        let userRole = req.session.userRole
        let idet = req.params.id
        let formShow = false
        if (userId == null) {
            res.redirect("/logind");
            return;
        }

        let kontakt_info = await querys.kontakt_info(beskeder)
        let checktimefunc = await beskedersql.checktime(kontakt_info)
        let kommentare = await querys.kommentare(idet)
        res.render('admin/pages/kommentare', {
            kontakt_info: kontakt_info,
            kontakt_array: checktimefunc,
            idet: idet,
            userRole: userRole,
            user: user,
            kommentare: kommentare,
            formShow: formShow
        })
    })

    app.get('/admin/artikler/kommentare/:id/:kommentarid', async function (req, res) {
        var user = req.session.user;
        let beskeder = beskedersql.beskeder
        let userId = req.session.userId
        let userRole = req.session.userRole
        let idet = req.params.id
        let kommentarid = req.params.kommentarid
        let formShow = true
        if (userId == null) {
            res.redirect("/logind");
            return;
        }

        let kontakt_info = await querys.kontakt_info(beskeder)
        let checktimefunc = await beskedersql.checktime(kontakt_info)
        let kommentare = await querys.kommentare(idet)
        let kommentar = await querys.kommentar(kommentarid)
        res.render('admin/pages/kommentare', {
            kontakt_info: kontakt_info,
            kontakt_array: checktimefunc,
            idet: idet,
            userRole: userRole,
            user: user,
            kommentare: kommentare,
            kommentarid: kommentarid,
            formShow: formShow,
            kommentar: kommentar
        })
    })
    app.post('/admin/artikler/kommentare/:id/:kommentarid', async function (req, res) {
        var user = req.session.user;
        let beskeder = beskedersql.beskeder
        let userId = req.session.userId
        let userRole = req.session.userRole
        let idet = req.params.id
        let kommentarid = req.params.kommentarid
        let kommentartekst = req.body.kommentar
        let formShow = true

        let updateKommentar = await querys.updateKommentar(kommentartekst, kommentarid)
        let kontakt_info = await querys.kontakt_info(beskeder)
        let checktimefunc = await beskedersql.checktime(kontakt_info)
        let kommentare = await querys.kommentare(idet)
        let kommentar = await querys.kommentar(kommentarid)
        res.render('admin/pages/kommentare', {
            kontakt_info: kontakt_info,
            kontakt_array: checktimefunc,
            idet: idet,
            userRole: userRole,
            user: user,
            kommentare: kommentare,
            kommentarid: kommentarid,
            formShow: formShow,
            kommentar: kommentar
        })
    })
    app.delete(['/admin/artikler/kommentare/:id/:kommentarid', '/admin/artikler/kommentare/:id'], async function (req, res) {
        var user = req.session.user;
        let beskeder = beskedersql.beskeder
        let userId = req.session.userId
        let userRole = req.session.userRole
        let idet = req.params.id
        let kommentarid = req.body.id
        let formShow = false

        await querys.sletKommentar(kommentarid)
        let kontakt_info = await querys.kontakt_info(beskeder)
        let checktimefunc = await beskedersql.checktime(kontakt_info)
        let kommentare = await querys.kommentare(idet)
        let kommentar = await querys.kommentar(kommentarid)
        res.render('admin/pages/kommentare', {
            kontakt_info: kontakt_info,
            kontakt_array: checktimefunc,
            idet: idet,
            userRole: userRole,
            user: user,
            kommentare: kommentare,
            kommentarid: kommentarid,
            formShow: formShow,
            kommentar: kommentar
        })
    })

}


// ###########################################

